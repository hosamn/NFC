function getParamValue(paramName) {
    // Reading parameter values
    
    var url = window.location.search.substring(1); //get rid of "?" in querystring
    var qArray = url.split('&'); //get key-value pairs
    
    for (var i = 0; i < qArray.length; i++) {
        var pArr = qArray[i].split('='); //split key and value
        if (pArr[0] == paramName)
            return pArr[1]; //return value
    }
}

// function zfill(num, len) {
//     return (Array(len).join("0") + num).slice(-len);
// }

var stationName = getParamValue("stationname");
var outputName  = getParamValue("outputname");
var stationType = getParamValue("stationtype");
var riverName   = getParamValue("rivername");
// var damname     = getParamValue("damname");
// var splitname   = station.split("%20Dam");   // %20 is space character
// var stationName = splitname[0];


// Reading The text Data files:

function levelData() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_Level.txt",
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}

function inflowData() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_Inflow.txt",
        //url: 'data/temperature/Conroe.txt',
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}

function outflowData_ALT() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_Outflow_ALT.txt",
        //url: 'data/temperature/Conroe.txt',
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}

function outflowData_L8() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_Outflow_L8.txt",
        //url: 'data/temperature/Conroe.txt',
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}

function outflowData_S1() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_Outflow_S1.txt",
        //url: 'data/temperature/Conroe.txt',
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}

function outflowData_S2() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_Outflow_S2.txt",
        //url: 'data/temperature/Conroe.txt',
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}

function storageData_ALT() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_Storage_ALT.txt",
        //url: 'data/temperature/Conroe.txt',
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}

function storageData_L8() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_Storage_L8.txt",
        //url: 'data/temperature/Conroe.txt',
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}

function storageData_S1() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_Storage_S1.txt",
        //url: 'data/temperature/Conroe.txt',
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}

function storageData_S2() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_Storage_S2.txt",
        //url: 'data/temperature/Conroe.txt',
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}

function inflowRangeData() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_Climatology.txt",
        //url: 'data/temperature/Conroe.txt',
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}

function outflowRangeData() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_Climatology.txt",
        //url: 'data/temperature/Conroe.txt',
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}

function storageRangeData() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_Climatology.txt",
        //url: 'data/temperature/Conroe.txt',
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}

function AEC() {
    dataset = '';
    // AJAX in the data file
    $.ajax({
        type: "GET",
        url: "data/" + outputName + "_AEC.txt",
        async: false,
        dataType: "text",
        success: function (data) {
            dataset = String(data);
        }
    });
    return dataset;
}


// Button Functions: Customizing Buttons, Parsing Text Data, Plotting Data:

function loadlevel() { // Reservoir/Station US Water Levels

    document.getElementById("btnlevel"  ).className = 'button     fit small';
    document.getElementById("btninflow" ).className = 'button alt fit small';
    document.getElementById("btnoutflow").className = 'button alt fit small reservoirButtons';
    document.getElementById("btnstorage").className = 'button alt fit small reservoirButtons';
    document.getElementById("btnaec"    ).className = 'button alt fit small reservoirButtons';

    //document.getElementById("note").innerHTML='';
    //document.getElementById("container").style.color = "#000000";

    $.ajax({
        success: function () {
            var level = []
            data = levelData();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split('\t');
                level.push([new Date(items[0]).getTime(), +items[1]]);
            }

            ///////////// Condition for Station Type ///////////////////////////

            var chartTitle = [];
            var chartSubtitle = [];
            var chartSeries = [];

            if (stationType == '1') {
                document.getElementById("btnlevel"  ).className = 'button     fit small';
                document.getElementById("btninflow" ).className = 'button alt fit small';
                document.getElementById("btnoutflow").className = 'button alt fit small reservoirButtons';
                document.getElementById("btnstorage").className = 'button alt fit small reservoirButtons';
                document.getElementById("btnaec"    ).className = 'button alt fit small reservoirButtons';
                
                //document.getElementById('reservoirButtons').style.display = 'block';
                //document.getElementById("note").innerHTML='';
                //document.getElementById("container").style.color = "#000000";

                /////////// Plot the Chart

                Highcharts.setOptions({
                    global: {
                        useUTC: false
                    }
                });

                chartTitle = {
                    text: "<strong>" + decodeURIComponent(stationName) + " Dam </strong>" + " (" + decodeURIComponent(riverName) + ")",
                    style: {
                        font: '20px bold Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };

                chartSubtitle = {
                    text: "US Water Level" ,
                    style: {
                        font: '18px Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };

                chartSeries = [
                    {
                        name: 'US Water Level',
                        data: level,
                        type: 'spline',
                        visible: true,
                        showInLegend: true,
                        marker: {enabled: false},
                        color: 'green',
                        zIndex: 1,
                        states: {hover: {lineWidthPlus: 0}}
                    },

                ];

                var chart = Highcharts.chart('container', {
                    chart: {
                        zoomType: 'x',
                        panning: true,
                        panKey: 'shift',

                        style: {
                            fontFamily: 'serif',
                            fontSize: '12px',
                            color: "#000000"
                        },
                    },

                    title: chartTitle,
                    
                    subtitle: chartSubtitle,

                    series: chartSeries,

                    xAxis: {
                        crosshair: true,
                        lineColor:'#B2BFB5',
                        lineWidth: 1,
                        type: 'datetime',
                        range: 12 * 30 * 24 * 3600 * 1000, // show only last 12 months
                        title: {
                            text: 'Date',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        }
                    },
                    yAxis: {
                        lineColor:'#B2BFB5',
                        lineWidth: 1,
                        title: {
                            text: 'Elevation AMSL (m)',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            format: '{value:.1f}',
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        minTickInterval: 0.1
                    },
                    tooltip: {
                        xDateFormat: '%d-%m-%Y',
                        crosshairs: true,
                        shared: true,
                        valueDecimals: 1,
                        valueSuffix: "m3/sec"
                    },
                    legend: {
                        backgroundColor: '#FFFFFF',
                        borderColor: '#FCFFC5',
                        borderWidth: 1,
                        enabled:true,
                        floating: false,
                        align: 'right',
                        verticalAlign: 'top',
                        layout: 'horizontal',
                        alignColumns: true,
                    },

                    credits: {
                        enabled: false
                    },

                });
            }

            else if (stationType == '2') {
                
                document.querySelectorAll(".reservoirButtons").forEach(i=>i.style.display = "none");
                
                document.getElementById("btnlevel" ).className = 'button     fit small';
                document.getElementById("btninflow").className = 'button alt fit small';
                
                //document.getElementById("note").innerHTML='';
                //document.getElementById("container").style.color = "#000000";

                //var theDiv = document.getElementById("note");
                //var content = document.createTextNode("Note that: The temperature is not available at US of the dam because the river width is narrower than the spatial resolution of the thermal bands in Landsat imagery");
                //theDiv.appendChild(content);

                /////////// Plot the Chart

                Highcharts.setOptions({
                    global: {
                        useUTC: false
                    }
                });
                
                chartTitle = {
                    text: "<strong>" +  decodeURIComponent(stationName) + " Station </strong>" + " (" + decodeURIComponent(riverName) + ")",
                    style: {
                        font: '20px bold Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };

                chartSubtitle = {
                    text: "Station Water Level",
                    style: {
                        font: '18px Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };
                chartSeries = [
                    {
                        name: 'Water Levels',
                        data: level,
                        type: 'spline',
                        marker: {enabled: false},
                        color: 'green',
                        zIndex: 1,
                        states: {hover: {lineWidthPlus: 0}}
                    },

                    // {
                    //   name: 'Level Climatology',
                    //   data: levelAVG,
                    //   type: 'spline',
                    //   dashStyle: 'Dot',
                    //   visible: true,
                    //   marker: {enabled: false},
                    //   color: Highcharts.getOptions().colors[0],
                    //   zIndex: 1,
                    //   states: {hover: {lineWidthPlus: 0}}},
                    //   {name: 'Standard Deviation of Level',
                    //   data: levelRange,
                    //   type: 'arearange',
                    //   fillOpacity: 0.3,
                    //   zIndex: 0,
                    //   lineWidth: 0,
                    //   linkedTo: ':previous',
                    //   visible: true,
                    //   color: Highcharts.getOptions().colors[0],
                    //   marker: {enabled: false},
                    // },

                ]

                /////////////// Plot the chart

                Highcharts.setOptions({
                    global: {
                        useUTC: false
                    }
                });

                var chart = Highcharts.chart('container', {
                    chart: {
                        zoomType: 'x',
                        panning: true,
                        panKey: 'shift',

                        style: {
                            fontFamily: 'serif',
                            fontSize: '12px',
                            color: "#000000"
                        },

                    },

                    title: chartTitle,

                    subtitle: chartSubtitle,

                    series: chartSeries,

                    xAxis: {
                        crosshair: true,
                        lineColor:'#B2BFB5',
                        lineWidth: 1,
                        type: 'datetime',
                        range: 12 * 30 * 24 * 3600 * 1000, // show only last 12 months

                        title: {
                            text: 'Date',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        }

                    },
                    yAxis: {
                        lineColor:'#B2BFB5',
                        lineWidth: 1,
                        title: {
                            text: 'Elevation AMSL (m)',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            format: '{value:.1f}',
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        minTickInterval: 0.1
                    },
                    tooltip: {
                        xDateFormat: '%d-%m-%Y',
                        crosshairs: true,
                        shared: true,
                        valueDecimals: 1,
                        valueSuffix: "m3/sec"
                    },
                    legend: {
                        backgroundColor: '#FFFFFF',
                        borderColor: '#FCFFC5',
                        borderWidth: 1,
                        enabled:true,
                        floating: false,
                        align: 'right',
                        verticalAlign: 'top',
                        layout: 'horizontal',
                        alignColumns: true,
                    },

                    credits: {
                        enabled: false
                    },

                });

            }
        }
    })
}

function loadinflow() { // Reservoir/Station Inflow

    document.getElementById("btnlevel"  ).className = 'button alt fit small';
    document.getElementById("btninflow" ).className = 'button     fit small';
    document.getElementById("btnoutflow").className = 'button alt fit small reservoirButtons';
    document.getElementById("btnstorage").className = 'button alt fit small reservoirButtons';
    document.getElementById("btnaec"    ).className = 'button alt fit small reservoirButtons';
    
    //document.getElementById("note").innerHTML='';
    //document.getElementById("container").style.color = "#000000";

    $.ajax({
        success: function () {
            var inflow = []
            data = inflowData();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split(',');
                inflow.push([new Date(items[0]).getTime(), +items[1]]);
            }

            var inflowRange = []
            var inflowAVG = []
            data = inflowRangeData();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split('\t');
                inflowAVG.push([new Date(items[0]).getTime(), +items[3]]);
                inflowRange.push([new Date(items[0]).getTime(), +items[4], +items[5]]);
            }

            ///////////// Condition for Station Type ///////////////////////////

            var chartTitle = [];
            var chartSubtitle = [];
            var chartSeries = [];

            if (stationType == '1') {
                document.getElementById("btnlevel"  ).className = 'button alt fit small';
                document.getElementById("btninflow" ).className = 'button     fit small';
                document.getElementById("btnoutflow").className = 'button alt fit small reservoirButtons';
                document.getElementById("btnstorage").className = 'button alt fit small reservoirButtons';
                document.getElementById("btnaec"    ).className = 'button alt fit small reservoirButtons';
                
                //document.getElementById('reservoirButtons').style.display = 'block';
                //document.getElementById("note").innerHTML='';
                //document.getElementById("container").style.color = "#000000";

                /////////// Plot the Chart

                Highcharts.setOptions({
                    global: {
                        useUTC: false
                    }
                });

                chartTitle = {
                    text: "<strong>" + decodeURIComponent(stationName) + " Dam </strong>" + " (" + decodeURIComponent(riverName) + ")",
                    style: {
                        font: '20px bold Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };

                chartSubtitle = {
                    text: "Inflow",
                    style: {
                        font: '18px Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };

                chartSeries = [
                    {
                        name: 'Inflow',
                        data: inflow,
                        type: 'spline',
                        visible: true,
                        showInLegend: true,
                        marker: {enabled: false},
                        color: 'green',
                        zIndex: 1,
                        states: {hover: {lineWidthPlus: 0}}
                    },

                    // { name: 'Inflow Climatology',
                    //   data: inflowAVG,
                    //   type: 'spline',
                    //   visible: true,
                    //   dashStyle: 'Dot',
                    //   showInLegend: true,
                    //   marker: { enabled: false },
                    //   color: Highcharts.getOptions().colors[0],
                    //   zIndex: 1,
                    //   states: { hover: { lineWidthPlus: 0 } }
                    //   },

                    //   {name: 'Standard Deviation of Reservoir Inflow',
                    //   data: inflowRange,
                    //   type: 'arearange',
                    //   fillOpacity: 0.3,
                    //   zIndex: 0,
                    //   lineWidth: 0,
                    //   linkedTo: ':previous',
                    //   visible: true,
                    //   color: Highcharts.getOptions().colors[0],
                    //   marker: { enabled: false },
                    //   },

                ];

                var chart = Highcharts.chart('container', {
                    chart: {
                        zoomType: 'x',
                        panning: true,
                        panKey: 'shift',

                        style: {
                            fontFamily: 'serif',
                            fontSize: '12px',
                            color: "#000000"
                        },

                    },

                    title: chartTitle,

                    subtitle: chartSubtitle,

                    series: chartSeries,

                    xAxis: {
                        crosshair: true,
                        lineColor:'#B2BFB5',
                        lineWidth: 1,
                        type: 'datetime',
                        range: 12 * 30 * 24 * 3600 * 1000, // show only last 12 months
                        title: {
                            text: 'Date',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        }

                    },
                    yAxis: {
                        lineColor:'#B2BFB5',
                        lineWidth: 1,
                        title: {
                            text: 'Inflow (m3/sec)',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            format: '{value:.1f}',
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        minTickInterval: 0.1
                    },
                    tooltip: {
                        xDateFormat: '%d-%m-%Y',
                        crosshairs: true,
                        shared: true,
                        valueDecimals: 1,
                        valueSuffix: "m3/sec"
                    },
                    legend: {
                        backgroundColor: '#FFFFFF',
                        borderColor: '#FCFFC5',
                        borderWidth: 1,
                        enabled:true,
                        floating: false,
                        align: 'right',
                        verticalAlign: 'top',
                        layout: 'horizontal',
                        alignColumns: true,
                    },

                    credits: {
                        enabled: false
                    },

                });
            }

            else if (stationType == '2') {

                document.querySelectorAll(".reservoirButtons").forEach(i=>i.style.display = "none");
                
                document.getElementById("btnlevel"  ).className = 'button alt fit small';
                document.getElementById("btninflow" ).className = 'button     fit small';

                //document.getElementById("note").innerHTML='';
                //document.getElementById("container").style.color = "#000000";

                //var theDiv = document.getElementById("note");
                //var content = document.createTextNode("Note that: The temperature is not available at US of the dam because the river width is narrower than the spatial resolution of the thermal bands in Landsat imagery");
                //theDiv.appendChild(content);

                chartTitle = {
                    text: "<strong>" +  decodeURIComponent(stationName) + " Station </strong>" + " (" + decodeURIComponent(riverName) + ")",
                    style: {
                        font: '20px bold Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };

                chartSubtitle = {
                    text:  "Station Inflow",
                    style: {
                        font: '18px Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };

                chartSeries = [
                    {
                        name: 'Inflow',
                        data: inflow,
                        type: 'spline',
                        marker: {enabled: false},
                        color: 'green',
                        zIndex: 1,
                        states: {hover: {lineWidthPlus: 0}}
                    },

                    // {name: 'Inflow Climatology',
                    //   data: inflowAVG,
                    //   type: 'spline',
                    //   dashStyle: 'Dot',
                    //   visible: true,
                    //   marker: {enabled: false},
                    //   color: Highcharts.getOptions().colors[0],
                    //   zIndex: 1,
                    //   states: {hover: {lineWidthPlus: 0}}},
                    //   {name: 'Standard Deviation of Inflow',
                    //   data: inflowRange,
                    //   type: 'arearange',
                    //   fillOpacity: 0.3,
                    //   zIndex: 0,
                    //   lineWidth: 0,
                    //   linkedTo: ':previous',
                    //   visible: true,
                    //   color: Highcharts.getOptions().colors[0],
                    //   marker: {enabled: false},
                    //   },

                ]

                /////////////// Plot the chart

                Highcharts.setOptions({
                    global: {
                        useUTC: false
                    }
                });

                var chart = Highcharts.chart('container', {
                    chart: {
                        zoomType: 'x',
                        panning: true,
                        panKey: 'shift',

                        style: {
                            fontFamily: 'serif',
                            fontSize: '12px',
                            color: "#000000"
                        },

                    },

                    title: chartTitle,
                   
                    subtitle: chartSubtitle,

                    series: chartSeries,

                    xAxis: {
                        crosshair: true,
                        lineColor:'#B2BFB5',
                        lineWidth: 1,
                        type: 'datetime',
                        range: 12 * 30 * 24 * 3600 * 1000, // show only last 12 months

                        title: {
                            text: 'Date',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        }

                    },
                    yAxis: {
                        lineColor:'#B2BFB5',
                        lineWidth: 1,
                        title: {
                            text: 'Inflow (m3/sec)',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            format: '{value:.1f}',
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        minTickInterval: 0.1
                    },
                    tooltip: {
                        xDateFormat: '%d-%m-%Y',
                        crosshairs: true,
                        shared: true,
                        valueDecimals: 1,
                        valueSuffix: "m3/sec"
                    },
                    legend: {
                        backgroundColor: '#FFFFFF',
                        borderColor: '#FCFFC5',
                        borderWidth: 1,
                        enabled:true,
                        floating: false,
                        align: 'right',
                        verticalAlign: 'top',
                        layout: 'horizontal',
                        alignColumns: true,
                    },
                    credits: {
                        enabled: false
                    },

                });

            }

        },

    });

}

function loadoutflow() { // Reservoir Outflow

    document.getElementById("btnlevel"  ).className = 'button alt fit small';
    document.getElementById("btninflow" ).className = 'button alt fit small';
    document.getElementById("btnoutflow").className = 'button     fit small reservoirButtons';
    document.getElementById("btnstorage").className = 'button alt fit small reservoirButtons';
    document.getElementById("btnaec"    ).className = 'button alt fit small reservoirButtons';

    //document.getElementById("note").innerHTML='';
    //document.getElementById("container").style.color = "#000000";

    $.ajax({
        success: function () {
            var outflow_ALT = []
            data = outflowData_ALT();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split(',');
                outflow_ALT.push([new Date(items[0]).getTime(), +items[1]]);
            }

            var outflowRange = []
            var outflowAVG = []
            data = outflowRangeData();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split('\t');
                outflowAVG.push([new Date(items[0]).getTime(), +items[3]]);
                outflowRange.push([new Date(items[0]).getTime(), +items[4], +items[5]]);
            }

            var outflow_L8 = []
            data = outflowData_L8();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split(',');
                outflow_L8.push([new Date(items[0]).getTime(), +items[1]]);
            }

            var outflow_S1 = []
            data = outflowData_S1();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split(',');
                outflow_S1.push([new Date(items[0]).getTime(), +items[1]]);
            }

            var outflow_S2 = []
            data = outflowData_S2();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split(',');
                outflow_S2.push([new Date(items[0]).getTime(), +items[1]]);
            }

            ///////////// Condition for Station Type ///////////////////////////

            var chartTitle = [];
            var chartSubtitle = [];
            var chartSeries = [];

            if (stationType == '1') {
                document.getElementById("btnlevel"  ).className = 'button alt fit small';
                document.getElementById("btninflow" ).className = 'button alt fit small';
                document.getElementById("btnoutflow").className = 'button     fit small reservoirButtons';
                document.getElementById("btnstorage").className = 'button alt fit small reservoirButtons';
                document.getElementById("btnaec"    ).className = 'button alt fit small reservoirButtons';
                
                //document.getElementById('reservoirButtons').style.display = 'block';
                //document.getElementById("note").innerHTML='';
                //document.getElementById("container").style.color = "#000000";
                
                /////////// Plot the Chart

                Highcharts.setOptions({
                    global: {
                        useUTC: false
                    }
                });

                chartTitle = {
                    text: "<strong>" + decodeURIComponent(stationName) + " Dam </strong>" + " (" + decodeURIComponent(riverName) + ")",
                    style: {
                        font: '20px bold Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };

                chartSubtitle = {
                    text: "Outflow",
                    style: {
                        font: '18px Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };

                chartSeries = [
                    {
                        name: 'Outflow',
                        data: outflow_ALT,
                        type: 'spline',
                        visible: true,
                        showInLegend: true,
                        marker: {enabled: false},
                        color: 'black',
                        zIndex: 1,
                        states: {hover: {lineWidthPlus: 0}}
                    },

                    {
                        name: 'Landsat-8 Outflow',
                        data: outflow_L8,
                        visible: true,
                        type: 'spline',
                        marker: {enabled: false},
                        color: 'blue',
                        zIndex: 1,
                        states: {hover: {lineWidthPlus: 0}}
                    },

                    {
                        name: 'Sentinel-1 Outflow',
                        data: outflow_S1,
                        type: 'spline',
                        visible: false,
                        marker: {enabled: false},
                        color: 'green',
                        zIndex: 1,
                        states: {hover: {lineWidthPlus: 0}}
                    },

                    {
                        name: 'Sentine-2 Outflow',
                        data: outflow_S2,
                        type: 'spline',
                        visible: false,
                        showInLegend: true,
                        marker: {enabled: false},
                        color: 'red',
                        zIndex: 1,
                        states: {hover: {lineWidthPlus: 0}}
                    },

                    // {name: 'Climatology',
                    //   data: outflowAVG,
                    //   visible: false,
                    //   type: 'spline',
                    //   dashStyle: 'Dot',
                    //   marker: {enabled: false},
                    //   color: Highcharts.getOptions().colors[0],
                    //   zIndex: 1,
                    //   states: {
                    //   hover: { lineWidthPlus: 0 } }
                    //   },

                    //   {name: 'Standard Deviation of Reservoir Outflow',
                    //   data: outflowRange,
                    //   visible: false,
                    //   type: 'arearange',
                    //   fillOpacity: 0.3,
                    //   zIndex: 0,
                    //   lineWidth: 0,
                    //   linkedTo: ':previous',
                    //   color: Highcharts.getOptions().colors[0],
                    //   marker: { enabled: false },
                    //   },

                ];

                var chart = Highcharts.chart('container', {
                    chart: {
                        zoomType: 'x',
                        panning: true,
                        panKey: 'shift',

                        style: {
                            fontFamily: 'serif',
                            fontSize: '12px',
                            color: "#000000"
                        },

                    },

                    title: chartTitle,

                    subtitle: chartSubtitle,

                    series: chartSeries,

                    xAxis: {
                        crosshair: true,
                        lineColor:'#B2BFB5',
                        lineWidth: 1,
                        type: 'datetime',
                        range: 12 * 30 * 24 * 3600 * 1000, // show only last 12 months
                        title: {
                            text: 'Date',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        }

                    },
                    yAxis: {
                        lineColor:'#B2BFB5',
                        lineWidth: 1,
                        title: {
                            text: 'Outflow (m3/sec)',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            format: '{value:.1f}',
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        minTickInterval: 0.1
                    },
                    tooltip: {
                        xDateFormat: '%d-%m-%Y',
                        crosshairs: true,
                        shared: true,
                        valueDecimals: 1,
                        valueSuffix: "m3/sec"
                    },
                    legend: {
                        backgroundColor: '#FFFFFF',
                        borderColor: '#FCFFC5',
                        borderWidth: 1,
                        enabled:true,
                        floating: false,
                        align: 'right',
                        verticalAlign: 'top',
                        layout: 'horizontal',
                        alignColumns: true,
                    },

                    credits: {
                        enabled: false
                    },

                });
            }

        },

    });

}

function loadstorage() { // Reservoir Storage

    document.getElementById("btnlevel"  ).className = 'button alt fit small';
    document.getElementById("btninflow" ).className = 'button alt fit small';
    document.getElementById("btnoutflow").className = 'button alt fit small reservoirButtons';
    document.getElementById("btnstorage").className = 'button     fit small reservoirButtons';
    document.getElementById("btnaec"    ).className = 'button alt fit small reservoirButtons';

    //document.getElementById("note").innerHTML='';
    //document.getElementById("container").style.color = "#000000";

    $.ajax({
        success: function () {
            var storage_ALT = []
            data = storageData_ALT();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split(',');
                storage_ALT.push([new Date(items[0]).getTime(), +items[1]]);
            }

            var storageRange = []
            var storageAVG = []
            data = storageRangeData();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split(',');
                storageAVG.push([new Date(items[0]).getTime(), +items[3]]);
                storageRange.push([new Date(items[0]).getTime(), +items[4], +items[5]]);
            }

            var storage_L8 = []
            data = storageData_L8();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split(',');
                storage_L8.push([new Date(items[0]).getTime(), +items[1]]);
            }

            var storage_S1 = []
            data = storageData_S1();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split(',');
                storage_S1.push([new Date(items[0]).getTime(), +items[1]]);
            }

            var storage_S2 = []
            data = storageData_S2();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split(',');
                storage_S2.push([new Date(items[0]).getTime(), +items[1]]);
            }

            ///////////// Condition for Station Type ///////////////////////////

            var chartTitle = [];
            var chartSubtitle = [];
            var chartSeries = [];

            if (stationType == '1') {
                document.getElementById("btnlevel"  ).className = 'button alt fit small';
                document.getElementById("btninflow" ).className = 'button alt fit small';
                document.getElementById("btnoutflow").className = 'button alt fit small reservoirButtons';
                document.getElementById("btnstorage").className = 'button     fit small reservoirButtons';
                document.getElementById("btnaec"    ).className = 'button alt fit small reservoirButtons';
                
                // document.getElementById('reservoirButtons').style.display = 'block';
                //document.getElementById("note").innerHTML='';
                //document.getElementById("container").style.color = "#000000";

                /////////// Plot the Chart

                Highcharts.setOptions({
                    global: {
                        useUTC: false
                    }
                });

                chartTitle = {
                    text: "<strong>" + decodeURIComponent(stationName) + " Dam </strong>" + " (" + decodeURIComponent(riverName) + ")",
                    style: {
                        font: '20px bold Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };

                chartSubtitle = {
                    text: "Storage Change",
                    style: {
                        font: '18px Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };

                chartSeries = [
                    {
                        name: 'Storage',
                        data: storage_ALT,
                        type: 'spline',
                        visible: true,
                        showInLegend: true,
                        marker: {enabled: false},
                        color: 'black',
                        zIndex: 1,
                        states: {hover: {lineWidthPlus: 0}}
                    },

                    {
                        name: 'Landsat-8',
                        data: storage_L8,
                        type: 'spline',
                        visible: true,
                        marker: {enabled: false},
                        color: 'blue',
                        zIndex: 1,
                        states: {hover: {lineWidthPlus: 0}}
                    },

                    {
                        name: 'Sentinel-2',
                        data: storage_S2,
                        type: 'spline',
                        visible: false,
                        marker: {enabled: false},
                        color: 'red',
                        zIndex: 1,
                        states: {hover: {lineWidthPlus: 0}}
                    },

                    {
                        name: 'Sentinel-1',
                        data: storage_S1,
                        type: 'spline',
                        marker: {enabled: false},
                        color: 'green',
                        visible: false,
                        zIndex: 1,
                        states: {hover: {lineWidthPlus: 0}}
                    },

                    // {name: 'Climatology',
                    //   data: storageAVG,
                    //   type: 'spline',
                    //   dashStyle: 'Dot',
                    //   visible: false,
                    //   marker: { enabled: false },
                    //   color: Highcharts.getOptions().colors[0],
                    //   zIndex: 1,
                    //   states: {hover: {lineWidthPlus: 0}}
                    //   },

                    //   {name: 'Standard Deviation of Reservoir Storage Change',
                    //   data: storageRange,
                    //   type: 'arearange',
                    //   fillOpacity: 0.3,
                    //   zIndex: 0,
                    //   lineWidth: 0,
                    //   linkedTo: ':previous',
                    //   visible: false,
                    //   color: Highcharts.getOptions().colors[0],
                    //   marker: { enabled: false },
                    //   },

                ];

                var chart = Highcharts.chart('container', {
                    chart: {
                        zoomType: 'x',
                        panning: true,
                        panKey: 'shift',

                        style: {
                            fontFamily: 'serif',
                            fontSize: '12px',
                            color: "#000000"
                        },

                    },
                    
                    title: chartTitle,

                    subtitle: chartSubtitle,

                    series: chartSeries,
                    
                    xAxis: {
                        crosshair: true,
                        lineColor:'#B2BFB5',
                        lineWidth: 1,
                        type: 'datetime',
                        range: 12 * 30 * 24 * 3600 * 1000, // show only last 12 months
                        title: {
                            text: 'Date',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        }

                    },
                    yAxis: {
                        lineColor:'#B2BFB5',
                        lineWidth: 1,
                        title: {
                            text: 'Storage Change (km3)',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            format: '{value:.1f}',
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        minTickInterval: 0.1
                    },
                    tooltip: {
                        xDateFormat: '%d-%m-%Y',
                        crosshairs: true,
                        shared: true,
                        valueDecimals: 1,
                        valueSuffix: "km3"
                    },
                    legend: {
                        backgroundColor: '#FFFFFF',
                        borderColor: '#FCFFC5',
                        borderWidth: 1,
                        enabled:true,
                        floating: false,
                        align: 'right',
                        verticalAlign: 'top',
                        layout: 'horizontal',
                        alignColumns: true,
                        //width:800,
                        //itemwidth:400,
                    },

                    credits: {
                        enabled: false
                    },

                });
            }
        },

    });

}

function loadaec() { // Reservoir Area Elevation Curve (Not the [discharge Stage] rating curve!)

    document.getElementById("btnlevel"  ).className = 'button alt fit small';
    document.getElementById("btninflow" ).className = 'button alt fit small';
    document.getElementById("btnoutflow").className = 'button alt fit small reservoirButtons';
    document.getElementById("btnstorage").className = 'button alt fit small reservoirButtons';
    document.getElementById("btnaec"    ).className = 'button     fit small reservoirButtons';

    //document.getElementById("note").innerHTML='';
    //document.getElementById("container").style.color = "#000000";

    $.ajax({
        success: function () {
            var aec = []
            data = AEC();
            lines = data.split('\n');
            for (i = 1; i < lines.length; i++) {
                var items = lines[i].split('\t');
                aec.push([items[0], +items[1]]);
            }

            ///////////// Condition for Station Type ///////////////////////////

            var chartTitle = [];
            var chartSubtitle = [];
            var chartSeries = [];

            if (stationType == '1') {
                document.getElementById("btnlevel"  ).className = 'button alt fit small';
                document.getElementById("btninflow" ).className = 'button alt fit small';
                document.getElementById("btnoutflow").className = 'button alt fit small reservoirButtons';
                document.getElementById("btnstorage").className = 'button alt fit small reservoirButtons';
                document.getElementById("btnaec"    ).className = 'button     fit small reservoirButtons';
                
                //document.getElementById('reservoirButtons').style.display = 'block';
                //document.getElementById("note").innerHTML='';
                //document.getElementById("container").style.color = "#000000";

                /////////// Plot the Chart

                Highcharts.setOptions({
                    global: {
                        useUTC: false
                    }
                });

                chartTitle = {
                    text: "<strong>" + decodeURIComponent(stationName) + " Dam </strong>" + " (" + decodeURIComponent(riverName) + ")",
                    style: {
                        font: '20px bold Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };

                chartSubtitle = {
                    text: "Area Elevation Curve",
                    style: {
                        font: '18px Times New Roman, sans-serif',
                        color: "#000000"
                    }
                };

                chartSeries = [
                    {
                        name: 'Area',
                        data: aec,
                        type: 'spline',
                        visible: true,
                        showInLegend: false,
                        marker: {enabled: false},
                        color: 'green',
                        zIndex: 1,
                        states: {hover: {lineWidthPlus: 0}}
                    },
                ];

                var chart = Highcharts.chart('container', {
                    chart: {
                        zoomType: 'x',
                        panning: true,
                        panKey: 'shift',

                        style: {
                            fontFamily: 'serif',
                            fontSize: '12px',
                            color: "#000000"
                        },

                    },

                    title: chartTitle,

                    subtitle: chartSubtitle,

                    series: chartSeries,

                    xAxis: {
                        crosshair: true,
                        lineColor:'#B2BFB5',
                        lineWidth: 1,

                        type: 'category',
                        tickInterval: 2,
                        title: {
                            text: 'Elevation AMSL (m)',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        }

                    },
                    yAxis: {
                        lineColor:'#B2BFB5',
                        lineWidth: 1,
                        title: {
                            text: 'Area (km2)',
                            style: {
                                font: '16px bold Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        labels: {
                            format: '{value:.1f}',
                            style: {
                                font: '16px Times New Roman, sans-serif',
                                color: "#000000"
                            }
                        },
                        minTickInterval: 0.1
                    },
                    tooltip: {
                        //xDateFormat: '%d-%m-%Y',
                        crosshairs: true,
                        shared: true,
                        valueDecimals: 1,
                        valueSuffix: "m3/sec"
                    },
                    legend: {
                        backgroundColor: '#FFFFFF',
                        borderColor: '#FCFFC5',
                        borderWidth: 1,
                        enabled:true,
                        floating: false,
                        align: 'right',
                        verticalAlign: 'top',
                        layout: 'horizontal',
                        alignColumns: true,
                    },

                    credits: {
                        enabled: false
                    },

                });
            }
        }
    })
}
